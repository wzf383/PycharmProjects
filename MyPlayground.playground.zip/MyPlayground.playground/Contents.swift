//: Playground - noun: a place where people can play

import UIKit
/*
var str = "Hello, playground"

func k(){
    var s:Int=1
    for a in 1...9
    {
        s=eat(x:s)
    }
    print(s)
}

func eat(x:Int)->Int
{
    return x*2+1
   
}
 print(k())



func count1(x:Int,y:Int,z:Int)->Int
{
    return x*3+y*2+z
}
for m in 1...20
{
    for f in 1...25
    {
        if(count1(x: m, y:f, z:30-m-f)==50)
        {
            print("x:\(m) y:\(f) z:\(30-m-f)")
        }
    }
}


func count1(a:[Int],n:Int=2)->Int
{
  var sum=0
    var temp=1
    for d in a{
        temp=1
        for k in 1...n{
            temp=temp*d
        }
        sum=sum+temp
        
    }
    return sum
}


print(count1(a:[1,2,3],n:3))

func count2(a:Double...)->Double
{
    var max:Double
   // max=a[]
    var m:[Double]=[Double]()
    for k in a{
        m.append(k)
    }
    max=m[0]
    for h in a{
        if(h>max){
            max=h
        }
    }
    return max
}
print(count2(a:2,43,2,65))







/*

func count2(a:Int...,n:Int=2)->Int
{
    var sum=0
    var temp=1
    for d in a{
        temp=1
        for k in 1...n{
            temp=temp*d
        }
        sum=sum+temp
        
    }
    return sum
}
print(count2(a:2,43,2,65))
*/

func count3(a:Double...)->(avg:Double,he:Double){
    var sum:Double=0
    var sum1:Double=0
    
    for k in a{
        sum=sum+k
        sum1=sum1+k*k
    }
    return (sum/Double(a.count),sum1)
}
var kk=count3(a:1,2,3)
print("平均值: \(kk.avg)  he:\(kk.he)")


*/
/*
func swap(a:inout Int, b:inout Int)
{
    let temp=a
    a=b
    b=temp
}
var c=1
var d=2
swap(a:&c,b:&d)
print(c)
*/
/*
func swap(x:inout Int)->Int
{
   var temp:Int=x
  // let temp=x
  
    for a in 1...temp
    {
       // s=eat(x:s)
        x=x*a
       // x=x+x
    }
   // x=temp*(temp-1)*(temp-2)
    // x=temp
   // x=b
    return xx
}
var xx=4

swap(x:&xx)
print(xx)
*/
/*
func swap(x:inout Int){
   
    var sum=1
    for a in 1...x
    {
      
        sum=sum*a
        x=sum
        
    }
    
}
var xx=6

swap(x:&xx)
print(xx)
*/
/*
func swap(a:inout Int, b:inout Int)
{
    let temp=a
    if(temp<b){
         a=b
    }
    
   // a=b
   // b=temp
}
var d=5
var e=10
//var f=3
swap(a:&d,b:&e)
print("a和b最大值: \(d)")
*/
//以下为可变参数
/*
func count2(c:Double...,max:inout Double)
{
    var temp=c[0]
    for k in c{
        if(k>temp)
        {
            temp=k
        }
    }
    max=temp
}

var s:Double=0
count2(c: 234,22,44,2,430, max:&s)
print(s)
*/
func count3(a:Double...,he:inout Double,avg:inout Double){
    var sum1:Double=0
    var sum2:Double=0
    for k in a{
        sum1=k*k+sum1
        sum2=sum2+k
    }
    he=sum1
    avg=sum2/Double(a.count)
    
}
var m:Double=0
var n:Double=0
count3(a:1,2,3,he:&m,avg:&n)
print("he:\(m)  avg:\(n)")





