//
//  Common.swift
//  黑马微博wzf
//
//  Created by apple on 17/12/11.
//  Copyright © 2017年 itheima. All rights reserved.
//

import UIKit

let WBSwithRootViewControllerNotification = "WBSwithRootViewControllerNotification"
