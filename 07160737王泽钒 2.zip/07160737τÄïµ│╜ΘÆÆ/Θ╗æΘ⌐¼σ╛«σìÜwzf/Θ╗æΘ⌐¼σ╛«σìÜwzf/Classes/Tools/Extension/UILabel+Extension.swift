//
//  UILabel+Extension.swift
//  黑马微博wzf
//
//  Created by apple on 17/12/11.
//  Copyright © 2017年 itheima. All rights reserved.
//

import UIKit
extension UILabel{
    convenience init(title:String,fontSize:CGFloat = 14,color:UIColor = UIColor.darkGray){
        self.init()
        text = title
        textColor = color
        font = UIFont.systemFont(ofSize: fontSize)
        numberOfLines = 0
        textAlignment = NSTextAlignment.center
    }
}

